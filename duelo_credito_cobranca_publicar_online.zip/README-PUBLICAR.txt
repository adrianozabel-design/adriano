MISSÃO CRÉDITO & COBRANÇA — PUBLICAR NA INTERNET

Este pacote contém o jogo multiplayer para duas pessoas, com salas independentes.
Não exige instalar Python nos computadores dos estudantes após publicar.

COMO PUBLICAR (GitHub + Render)
1. Acesse https://github.com/new e crie um repositório para o jogo.
2. No repositório, escolha Add file > Upload files e envie diretamente os cinco arquivos desta pasta (sem a pasta externa):
   index.html, servidor.py, requirements.txt, render.yaml, README-PUBLICAR.txt.
3. Confirme em Commit changes.
4. Acesse https://dashboard.render.com/ e conecte sua conta do GitHub.
5. Escolha New > Web Service e selecione o repositório recém-criado.
6. Se solicitado, escolha Language Python 3, Instance Type Free,
   Build Command: pip install -r requirements.txt
   Start Command: python servidor.py
7. Clique em Deploy Web Service. Aguarde o status Live.
8. Copie o endereço https://SEU-NOME.onrender.com que o Render mostrar.
9. Abra o MESMO endereço nos dois computadores. Um estudante cria a sala
   e compartilha o código com o colega.

OBSERVAÇÕES IMPORTANTES
- O endereço real só existe após a publicação na sua conta de hospedagem.
- A versão gratuita do Render hiberna após período de inatividade;
  ao reiniciar, salas e placares em andamento são perdidos.
- Para uma aula, abra o site antes e use uma sala por dupla.
- Não cadastre informações pessoais sensíveis: use apenas primeiros nomes
  ou apelidos fictícios.
- Para uso institucional permanente, recomenda-se armazenamento persistente,
  controles de acesso e revisão de segurança pelo setor de TI.
- O jogo usa solicitações frequentes (polling) para sincronizar as telas.
- As regras financeiras são cenários pedagógicos fictícios.
