#!/usr/bin/env python3
"""Simulador didático para LAN. Requer apenas Python 3.9+."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse,parse_qs
import json, random, string, threading, time, socket, os, secrets

ROOT=Path(__file__).resolve().parent
LOCK=threading.RLock()
ROOMS={}
CASES=[
 {'name':'Confecções Aurora','debt':4800,'late':15,'story':'Vendas sazonais reduziram o caixa. A empresa quer preservar a parceria.','client':'Você consegue pagar entrada de até R$ 1.600 agora e mais duas parcelas de até R$ 1.700. Prefere não pagar tudo de uma vez.','max_entry':1600,'max_installment':1700},
 {'name':'Moda Sul','debt':12000,'late':40,'story':'Atraso no recebimento de grandes compradores. Há risco de interrupção do fornecimento.','client':'Você dispõe de R$ 4.000 de entrada. Depois, pode pagar duas parcelas de até R$ 4.300. Peça mais prazo se necessário.','max_entry':4000,'max_installment':4300},
 {'name':'Tecidos Brasil','debt':18000,'late':65,'story':'A empresa já descumpriu um acordo anterior e solicita renegociação.','client':'Seu caixa permite entrada de até R$ 5.700 e duas parcelas de no máximo R$ 6.200. Seu objetivo é obter desconto.','max_entry':5700,'max_installment':6200},
 {'name':'Malhas União','debt':8000,'late':7,'story':'Cliente estratégico quer regularizar pendência para solicitar novo crédito.','client':'Você tem R$ 2.500 disponíveis para entrada e suporta duas parcelas de até R$ 2.850. Quer negociar nova liberação de crédito.','max_entry':2500,'max_installment':2850}
]

def room_code():
 while True:
  code=''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZ23456789',k=6))
  if code not in ROOMS:return code

def public_state(r, token):
 idx=next((i for i,p in enumerate(r['players']) if p['token']==token),None)
 if idx is None:return None
 role='analista' if idx==r['round']%2 else 'cliente'
 c=CASES[r['round']] if r['round']<len(CASES) else None
 return {'room':r['code'],'you':idx,'players':[p['name'] for p in r['players']], 'ready':len(r['players'])==2,'round':r['round'],'finished':r['round']>=4,'role':role,'case':({'name':c['name'],'debt':c['debt'],'late':c['late'],'story':c['story'],'client_secret':c['client'] if role=='cliente' else None} if c else None),'phase':r['phase'],'offer':r['offer'],'history':r['history'],'score':r['score'],'results':r['results'],'turns':r['turns'],'revision':r['revision']}

def offer_check(c,amount,entry,installments):
 if not isinstance(amount,(int,float)) or not isinstance(entry,(int,float)) or not isinstance(installments,int):return 'Valores inválidos.'
 if not (0<=amount<=c['debt']) or entry<0 or installments not in (0,1,2):return 'Preencha um valor negociado positivo, com 0 a 2 parcelas após a entrada.'
 discount=(c['debt']-amount)/c['debt']*100
 if discount>5.000001:return 'Desconto superior a 5% exige aprovação. Revise a proposta.'
 if amount<=0 or entry>amount or entry+0.001 < amount*.30:return 'Entrada mínima de 30% não atendida.'
 if installments==0 and abs(entry-amount)>.01:return 'Para quitação à vista, a entrada deve ser o valor negociado.'
 if installments>0 and amount-entry<=0:return 'Informe um saldo positivo para parcelar.'
 return None

class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def reply(self,data,status=200):
  b=json.dumps(data,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 def body(self):
  n=int(self.headers.get('Content-Length','0'))
  if n>12000:raise ValueError('Mensagem grande demais.')
  return json.loads(self.rfile.read(n) or b'{}')
 def do_GET(self):
  path=urlparse(self.path)
  if path.path=='/':
   b=(ROOT/'index.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
  if path.path=='/api/state':
   q=parse_qs(path.query);code=q.get('code',[''])[0].upper();token=q.get('token',[''])[0]
   with LOCK:
    r=ROOMS.get(code);s=public_state(r,token) if r else None
   return self.reply({'ok':bool(s),'state':s,'error':None if s else 'Sala ou sessão não encontrada.'},200 if s else 404)
  self.reply({'error':'Não encontrado'},404)
 def do_POST(self):
  try:
   d=self.body();path=urlparse(self.path).path
   with LOCK:
    if path=='/api/create':
     name=str(d.get('name','')).strip()[:28]
     if not name:raise ValueError('Informe um nome.')
     code=room_code();token=secrets.token_urlsafe(32)
     r={'code':code,'players':[{'name':name,'token':token}],'round':0,'phase':'waiting','offer':None,'history':[],'results':[],'score':[0,0],'turns':0,'revision':0}
     ROOMS[code]=r;return self.reply({'ok':True,'code':code,'token':token})
    if path=='/api/join':
     code=str(d.get('code','')).strip().upper();name=str(d.get('name','')).strip()[:28];r=ROOMS.get(code)
     if not name or not r:raise ValueError('Verifique o nome e o código da sala.')
     if len(r['players'])>=2:raise ValueError('A sala já tem dois participantes.')
     token=secrets.token_urlsafe(32)
     r['players'].append({'name':name,'token':token});r['phase']='analyst';r['revision']+=1
     return self.reply({'ok':True,'code':code,'token':token})
    code=str(d.get('code','')).upper();r=ROOMS.get(code);token=d.get('token');idx=next((i for i,p in enumerate(r['players']) if p['token']==token),None) if r else None
    if idx is None or len(r['players'])<2 or r['round']>=4:raise ValueError('Sessão inválida ou encerrada.')
    role='analista' if idx==r['round']%2 else 'cliente';c=CASES[r['round']]
    if path=='/api/offer':
     if role!='analista' or r['phase']!='analyst':raise ValueError('Aguarde a sua vez de apresentar uma proposta.')
     amount=round(float(d.get('amount')),2);entry=round(float(d.get('entry')),2);installments=int(d.get('installments'))
     invalid=offer_check(c,amount,entry,installments)
     if invalid:raise ValueError(invalid)
     if r['turns']>=4:raise ValueError('Limite de propostas nesta rodada.')
     r['turns']+=1
     offer={'amount':amount,'entry':entry,'installments':installments,'installment_value':round((amount-entry)/installments,2) if installments else 0,'discount':round((c['debt']-amount)/c['debt']*100,2),'note':str(d.get('note','')).strip()[:240]}
     r['offer']=offer;r['phase']='client';r['history'].append({'by':'Analista','message':f'Proposta {r["turns"]}: R$ {amount:.2f}, entrada R$ {entry:.2f}, saldo em {installments} parcelas. {offer["note"]}'})
    elif path=='/api/respond':
     if role!='cliente' or r['phase']!='client' or not r['offer']:raise ValueError('Aguarde uma proposta para responder.')
     action=d.get('action');note=str(d.get('note','')).strip()[:240];o=r['offer']
     if action=='accept':
      # Real affordability check belongs to server; the client secret is guidance, not a hard lock.
      client_points=20 if o['entry']<=c['max_entry']+.01 and (o['installments']==0 or o['installment_value']<=c['max_installment']+.01) else 7
      analyst_points=20 if o['discount']<=3 else 17
      r['score'][r['round']%2]+=analyst_points;r['score'][1-r['round']%2]+=client_points
      r['history'].append({'by':'Cliente','message':'Acordo aceito. '+note});r['results'].append({'case':c['name'],'type':'Acordo','analyst':analyst_points,'client':client_points,'offer':o})
      r['phase']='end'
     elif action=='counter':
      r['history'].append({'by':'Cliente','message':'Contraproposta: '+(note or 'Preciso de condições melhores.')})
      if r['turns']>=4:
       r['results'].append({'case':c['name'],'type':'Sem acordo','analyst':5,'client':5,'offer':o});r['score'][0]+=5;r['score'][1]+=5;r['phase']='end'
      else:r['phase']='analyst'
     elif action=='reject':
      r['history'].append({'by':'Cliente','message':'Proposta recusada. '+note});r['results'].append({'case':c['name'],'type':'Sem acordo','analyst':5,'client':5,'offer':o});r['score'][0]+=5;r['score'][1]+=5;r['phase']='end'
     else:raise ValueError('Resposta inválida.')
    elif path=='/api/advance':
     if r['phase']!='end':raise ValueError('A rodada ainda não terminou.')
     r['round']+=1;r['phase']='analyst' if r['round']<4 else 'finished';r['offer']=None;r['history']=[];r['turns']=0
    else:raise ValueError('Ação desconhecida.')
    r['revision']+=1
    return self.reply({'ok':True})
  except (ValueError,TypeError,OverflowError) as e:self.reply({'ok':False,'error':str(e)},400)
  except Exception:self.reply({'ok':False,'error':'Não foi possível concluir a ação.'},500)

if __name__=='__main__':
 port=int(os.environ.get('PORT','8000'))
 hostname=socket.gethostname()
 try:ip=socket.gethostbyname(hostname)
 except:ip='IP_DO_PROFESSOR'
 print('\nDuelo Crédito & Cobrança – multiplayer')
 print('Neste computador: http://localhost:'+str(port))
 print('Nos demais computadores: http://'+ip+':'+str(port))
 print('Se o IP indicado não funcionar, confira o IPv4 do computador com ipconfig.')
 print('Mantenha esta janela aberta. Para encerrar: Ctrl+C.\n')
 ThreadingHTTPServer(('0.0.0.0',port),Handler).serve_forever()
